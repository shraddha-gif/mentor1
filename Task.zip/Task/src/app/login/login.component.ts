import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MentorService } from '../mentor.service';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  mentor: any;
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private mentorService: MentorService) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ["", Validators.required],
      password: ["", Validators.required]
    });
  }
  login() {
    console.log(this.loginForm);
    this.mentorService.getMentors();
    alert("Login Succesfull");
    this.router.navigate(["/mentor"]);
  }
  get f() {
    return this.loginForm.controls;
  }

}
