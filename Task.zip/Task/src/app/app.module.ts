import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { ProfileComponent } from './mentor1/component/profile/profile.component';
// import { AdminDashaboardComponent } from './mentor1/component/admin-dashaboard/admin-dashaboard.component';
// import { MentorListComponent } from './mentor1/component/mentor-list/mentor-list.component';
// import { ChangePasswordComponent } from './mentor1/component/change-password/change-password.component';
import { MatFormFieldModule } from '@angular/material/form-field';
// import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MatMenuModule } from '@angular/material/menu';
// import { AdminPanelComponent } from './mentor1/component/admin-panel/admin-panel.component';


@NgModule({

  // schemas: [CUSTOM_ELEMENTS_SCHEMA],

  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    LoginComponent,
    PageNotFoundComponent,
    RegisterComponent,
    // AdminPanelComponent
    // ProfileComponent,
    // AdminDashaboardComponent,
    // MentorListComponent,
    // ChangePasswordComponent,
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatFormFieldModule,
    MatMenuModule
   ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
