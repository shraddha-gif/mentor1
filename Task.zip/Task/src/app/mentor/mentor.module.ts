import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MentorRoutingModule } from './mentor-routing.module';
import { LayoutModule } from "@angular/cdk/layout";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";
import { MatListModule } from "@angular/material/list";
import { MatTableModule } from "@angular/material/table";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatSortModule } from "@angular/material/sort";
import { MatGridListModule } from "@angular/material/grid-list";
import { MatCardModule } from "@angular/material/card";
import { MatMenuModule } from "@angular/material/menu";
import { MatInputModule } from "@angular/material/input";

import { MentorListComponent } from '../mentor1/component/mentor-list/mentor-list.component';
import { AdminDashaboardComponent } from '../mentor1/component/admin-dashaboard/admin-dashaboard.component';
import { ProfileComponent } from '../mentor1/component/profile/profile.component';
import { MatFormFieldModule} from '@angular/material/form-field';
import { ChangePasswordComponent } from '../mentor1/component/change-password/change-password.component';
import { AdminPanelComponent } from '../mentor1/component/admin-panel/admin-panel.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    
    MentorListComponent,
    AdminDashaboardComponent,
    ProfileComponent,
    ChangePasswordComponent,
    AdminPanelComponent

 ],
  imports: [
   
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatFormFieldModule,
   MentorRoutingModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    MatInputModule,
  ]

})
export class MentorModule { }
