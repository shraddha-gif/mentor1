import { NgModule } from "@angular/core";
import { Routes,RouterModule} from "@angular/router";

import { AdminDashaboardComponent } from '../mentor1/component/admin-dashaboard/admin-dashaboard.component';
import { MentorListComponent} from '../mentor1/component/mentor-list/mentor-list.component';
import { ProfileComponent } from '../mentor1/component/profile/profile.component';
import { ChangePasswordComponent } from '../mentor1/component/change-password/change-password.component';
import { AdminPanelComponent } from '../mentor1/component/admin-panel/admin-panel.component';


const routes: Routes = [
  {
    path: "",
    component: AdminPanelComponent,
    children: [
      { path: "dashboard", component: AdminDashaboardComponent },
      { path: "mentor", component: MentorListComponent },
      { path: "profile", component: ProfileComponent },
      { path: "changepassword", component: ChangePasswordComponent }
    ]
  }
];
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
export class MentorRoutingModule {}
