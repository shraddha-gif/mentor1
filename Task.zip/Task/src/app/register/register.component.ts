import { Component, OnInit } from '@angular/core';
import { MentorService } from "../mentor.service";
import { FormGroup, Validators, FormBuilder } from "@angular/forms";
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  rform: FormGroup;

  message;
  constructor(private fb: FormBuilder, private reg: MentorService) { }

  ngOnInit() {
    this.rform = this.fb.group({
      name: [
        "",
        Validators.compose([
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(20)
        ])
      ],
      email: ["", Validators.compose([Validators.required, Validators.email])],
      mobile: [
        "",
        Validators.compose([Validators.required, Validators.minLength(10)])
      ],
      password: ["", Validators.compose([Validators.required])],
      confirmpassword: ["", Validators.compose([Validators.required])]
    });
  }
  register() {
    console.log(this.rform);
    this.reg.register(this.rform.value);
    alert("Registered Succesfull");
  }

  get f() {
    return this.rform.controls;
  }

}
