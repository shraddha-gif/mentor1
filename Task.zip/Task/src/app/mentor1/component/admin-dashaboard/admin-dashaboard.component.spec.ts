import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDashaboardComponent } from './admin-dashaboard.component';

describe('AdminDashaboardComponent', () => {
  let component: AdminDashaboardComponent;
  let fixture: ComponentFixture<AdminDashaboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminDashaboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDashaboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
