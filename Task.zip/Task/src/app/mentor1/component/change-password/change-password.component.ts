import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  constructor(private fb: FormBuilder) {}

  frm: FormGroup;

  ngOnInit() {
    this.frm = this.fb.group({
      ppass: ["", Validators.required],
      npass: ["", Validators.required],
      rpass: ["", Validators.required]
    });
  }
  flag;
  update() {
    //  this.reg.sturegister(this.frm.value);
  }

}
