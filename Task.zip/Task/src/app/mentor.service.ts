import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  constructor() { }

  getMentors() {
    return {
      name: localStorage.getItem("name"),
      mobile: localStorage.getItem("mobile"),
      email: localStorage.getItem("email"),
      password: localStorage.getItem("password"),
      confirmpassword: localStorage.getItem("confirmpassword")
    };
  }
  register(mentor) {
    localStorage.setItem("name", mentor.name);
    localStorage.setItem("email", mentor.email);
    localStorage.setItem("mobile", mentor.mobile);
    localStorage.setItem("password", mentor.password);
    localStorage.setItem("confirmpassword", mentor.confirmpassword);
  }
}
